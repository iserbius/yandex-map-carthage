#import <YandexMapKitSearch/YMKSearchMenuItem.h>

/// @cond EXCLUDE
/**
 * Multiple menu entries.
 */
@interface YMKSearchMenuInfo : NSObject

/**
 * Menu items.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchMenuItem *> *menuItems;


+ (nonnull YMKSearchMenuInfo *)menuInfoWithMenuItems:(nonnull NSArray<YMKSearchMenuItem *> *)menuItems;


@end
/// @endcond

