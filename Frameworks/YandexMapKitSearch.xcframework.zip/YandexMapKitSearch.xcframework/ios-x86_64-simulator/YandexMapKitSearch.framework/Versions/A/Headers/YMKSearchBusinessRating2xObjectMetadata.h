#import <Foundation/Foundation.h>

/**
 * Snippet for business ratings. Score from 0 to 10.
 */
@interface YMKSearchBusinessRating2xObjectMetadata : NSObject

/**
 * Total number of ratings.
 */
@property (nonatomic, readonly) NSUInteger ratings;

/**
 * Total number of reviews.
 */
@property (nonatomic, readonly) NSUInteger reviews;

/**
 * Average rating score for the business (0 to 10).
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSNumber *score;


+ (nonnull YMKSearchBusinessRating2xObjectMetadata *)businessRating2xObjectMetadataWithRatings:( NSUInteger)ratings
                                                                                       reviews:( NSUInteger)reviews
                                                                                         score:(nullable NSNumber *)score;


@end

