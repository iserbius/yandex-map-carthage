#import <YandexMapKitSearch/YMKSearchMassTransit1xObjectMetadata.h>

#import <yandex/maps/mapkit/search/masstransit_1x_object_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


