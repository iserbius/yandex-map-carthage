#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Listener to be notified when a new menu is received.
 */
@protocol YMKSearchMenuListener <NSObject>

/**
 * Gets called upon receiving new menu data.
 */
- (void)onMenuReceived;


@end
/// @endcond
