#import <YandexMapKitSearch/YMKSearchBookingOffer.h>
#import <YandexMapKitSearch/YMKSearchBookingParams.h>

/// @cond EXCLUDE
/**
 * Response to find booking offers request.
 */
@interface YMKSearchBookingResponse : NSObject

/**
 * Common booking parameters.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchBookingParams *params;

/**
 * List of partner offers.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchBookingOffer *> *offers;


+ (nonnull YMKSearchBookingResponse *)bookingResponseWithParams:(nullable YMKSearchBookingParams *)params
                                                         offers:(nonnull NSArray<YMKSearchBookingOffer *> *)offers;


@end
/// @endcond

