#import <YandexMapKitSearch/YMKSearchGoodsCategory.h>

/// @cond EXCLUDE
/**
 * Full goods register.
 */
@interface YMKSearchGoodsRegister : NSObject

/**
 * Goods grouped by named categories.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchGoodsCategory *> *categories;

/**
 * Unspecified additional info, e.g. goods kind ('menu', 'drugs', etc).
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;


+ (nonnull YMKSearchGoodsRegister *)goodsRegisterWithCategories:(nonnull NSArray<YMKSearchGoodsCategory *> *)categories
                                                           tags:(nonnull NSArray<NSString *> *)tags;


@end
/// @endcond

