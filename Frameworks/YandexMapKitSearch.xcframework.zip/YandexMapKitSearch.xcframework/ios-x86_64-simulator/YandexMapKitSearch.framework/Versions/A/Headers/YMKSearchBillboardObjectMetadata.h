#import <YandexMapKitSearch/YMKSearchAction.h>
#import <YandexMapKitSearch/YMKSearchCreative.h>
#import <YandexMapKitSearch/YMKSearchDisclaimer.h>
#import <YandexMapKitSearch/YMKSearchKeyValuePair.h>

/// @cond EXCLUDE
/**
 * Contains information about a billboard.
 */
@interface YMKSearchBillboardObjectMetadata : NSObject

/**
 * Billboard ID.
 */
@property (nonatomic, readonly, nonnull) NSString *placeId;

/**
 * Title.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *title;

/**
 * Address.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *address;

/**
 * Billboard actions.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchAction *> *actions;

/**
 * Billboard creatives.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchCreative *> *creatives;

/**
 * Billboard disclaimers.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchDisclaimer *> *disclaimers;

/**
 * Additional billboard properties.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchKeyValuePair *> *properties;

/**
 * Opaque string for logging.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *logId;


+ (nonnull YMKSearchBillboardObjectMetadata *)billboardObjectMetadataWithPlaceId:(nonnull NSString *)placeId
                                                                           title:(nullable NSString *)title
                                                                         address:(nullable NSString *)address
                                                                         actions:(nonnull NSArray<YMKSearchAction *> *)actions
                                                                       creatives:(nonnull NSArray<YMKSearchCreative *> *)creatives
                                                                     disclaimers:(nonnull NSArray<YMKSearchDisclaimer *> *)disclaimers
                                                                      properties:(nonnull NSArray<YMKSearchKeyValuePair *> *)properties
                                                                           logId:(nullable NSString *)logId;


@end
/// @endcond

