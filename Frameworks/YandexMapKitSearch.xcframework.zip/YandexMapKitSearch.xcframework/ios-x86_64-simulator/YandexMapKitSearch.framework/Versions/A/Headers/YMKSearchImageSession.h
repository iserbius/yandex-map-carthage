#import <YandexMapKitSearch/YMKSearchImageDownloader.h>

/// @cond EXCLUDE
/**
 * Session for receiving search-related bitmaps (e.g. advertisement
 * images).
 *
 * - Should be stored until listener is notified. - Can be used to
 * cancel active request. - Can be used to retry last request (usually
 * if it failed).
 */
@interface YMKSearchImageSession : NSObject

/**
 * Cancel current request.
 */
- (void)cancel;


/**
 * Retry last request. If there is an active request, it is cancelled.
 *
 * @param imageListener new listener to be notified
 */
- (void)retryWithImageListener:(nonnull YMKSearchImageListener)imageListener;


@end
/// @endcond

