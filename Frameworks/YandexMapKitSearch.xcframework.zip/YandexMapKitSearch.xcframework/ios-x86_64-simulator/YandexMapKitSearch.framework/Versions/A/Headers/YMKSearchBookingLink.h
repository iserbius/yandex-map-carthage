#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Typed link to actual booking.
 */
@interface YMKSearchBookingLink : NSObject

/**
 * Link type.
 */
@property (nonatomic, readonly, nonnull) NSString *type;

/**
 * Link uri.
 */
@property (nonatomic, readonly, nonnull) NSString *uri;


+ (nonnull YMKSearchBookingLink *)bookingLinkWithType:(nonnull NSString *)type
                                                  uri:(nonnull NSString *)uri;


@end
/// @endcond

