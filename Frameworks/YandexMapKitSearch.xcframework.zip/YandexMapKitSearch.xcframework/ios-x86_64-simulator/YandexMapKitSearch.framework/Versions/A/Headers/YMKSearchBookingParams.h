#import <YandexMapKit/YMKTime.h>

/// @cond EXCLUDE
/**
 * Common parameters for booking response.
 */
@interface YMKSearchBookingParams : NSObject

/**
 * Date of check-in in UTC time zone.
 */
@property (nonatomic, readonly, nonnull) YMKTime *checkIn;

/**
 * Nights of stay.
 */
@property (nonatomic, readonly) NSUInteger nights;

/**
 * Number of persons to stay.
 */
@property (nonatomic, readonly) NSUInteger persons;


+ (nonnull YMKSearchBookingParams *)bookingParamsWithCheckIn:(nonnull YMKTime *)checkIn
                                                      nights:( NSUInteger)nights
                                                     persons:( NSUInteger)persons;


@end
/// @endcond

