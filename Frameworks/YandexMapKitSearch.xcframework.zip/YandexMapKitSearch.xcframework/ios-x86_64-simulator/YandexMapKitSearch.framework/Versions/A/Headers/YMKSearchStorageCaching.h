#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Enum to control caching of downloaded images to device storage.
 */
typedef NS_ENUM(NSUInteger, YMKSearchStorageCaching) {

    YMKSearchStorageCachingEnabled,

    YMKSearchStorageCachingDisabled
};
/// @endcond

