#import <YandexMapKitSearch/YMKSearchLogger.h>

#import <yandex/maps/mapkit/search/logger.h>

#import <memory>

@interface YMKSearchLogger ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(const std::shared_ptr<::yandex::maps::mapkit::search::Logger>&)native;

- (std::shared_ptr<::yandex::maps::mapkit::search::Logger>)nativeLogger;
- (std::shared_ptr<::yandex::maps::mapkit::search::Logger>)native;

@end
