#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Typed link to photo.
 */
@interface YMKSearchPhotoLink : NSObject

/**
 * Photo type.
 */
@property (nonatomic, readonly, nonnull) NSString *type;

/**
 * Photo uri.
 */
@property (nonatomic, readonly, nonnull) NSString *uri;


+ (nonnull YMKSearchPhotoLink *)photoLinkWithType:(nonnull NSString *)type
                                              uri:(nonnull NSString *)uri;


@end
/// @endcond

