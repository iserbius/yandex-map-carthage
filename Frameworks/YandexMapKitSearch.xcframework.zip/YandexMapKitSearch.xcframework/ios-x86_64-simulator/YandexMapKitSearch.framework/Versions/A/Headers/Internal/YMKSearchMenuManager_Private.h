#import <YandexMapKitSearch/YMKSearchMenuManager.h>

#import <YandexRuntime/YRTSubscription.h>

#import <yandex/maps/mapkit/search/menu_manager.h>
#import <yandex/maps/runtime/ios/object.h>

#import <memory>

@interface YMKSearchMenuManager ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(const std::shared_ptr<::yandex::maps::mapkit::search::MenuManager>&)native;

- (std::shared_ptr<::yandex::maps::mapkit::search::MenuManager>)nativeMenuManager;
- (std::shared_ptr<::yandex::maps::mapkit::search::MenuManager>)native;

@end
