#import <YandexMapKitSearch/YMKSearchPlaceInfo.h>

/// @cond EXCLUDE
/**
 * Snippet data to get related adverts info.
 */
@interface YMKSearchRelatedAdvertsObjectMetadata : NSObject

/**
 * List of related advertized places.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchPlaceInfo *> *places;


+ (nonnull YMKSearchRelatedAdvertsObjectMetadata *)relatedAdvertsObjectMetadataWithPlaces:(nonnull NSArray<YMKSearchPlaceInfo *> *)places;


@end
/// @endcond

