#import <YandexMapKitSearch/YMKSearchZeroSpeedBannerManager.h>

#import <yandex/maps/mapkit/search/zero_speed_banner_manager.h>

#import <memory>

@interface YMKSearchZeroSpeedBannerManager ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(const std::shared_ptr<::yandex::maps::mapkit::search::ZeroSpeedBannerManager>&)native;

- (std::shared_ptr<::yandex::maps::mapkit::search::ZeroSpeedBannerManager>)nativeZeroSpeedBannerManager;
- (std::shared_ptr<::yandex::maps::mapkit::search::ZeroSpeedBannerManager>)native;

@end
