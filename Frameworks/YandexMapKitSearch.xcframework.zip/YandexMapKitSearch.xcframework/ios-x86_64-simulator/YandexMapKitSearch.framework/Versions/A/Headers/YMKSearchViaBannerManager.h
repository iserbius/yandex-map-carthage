#import <YandexMapKitSearch/YMKSearchViaBannerSession.h>

#import <YandexMapKit/YMKPolyline.h>

/// @cond EXCLUDE
/**
 * Allows to get via-point advertisement for the route.
 */
@interface YMKSearchViaBannerManager : NSObject

/**
 * Begins asynchronous request for via banner.
 *
 * @param route Route to request via banner advertisement for.
 * @param bannerListener Listener for result.
 */
- (nonnull YMKSearchViaBannerSession *)requestViaBannerWithRoute:(nonnull YMKPolyline *)route
                                                 responseHandler:(nonnull YMKSearchViaBannerSessionResponseHandler)responseHandler;


@end
/// @endcond

