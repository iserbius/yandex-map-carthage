#import <YandexMapKitSearch/YMKSearchImage.h>
#import <YandexMapKitSearch/YMKSearchKeyValuePair.h>

/// @cond EXCLUDE
/**
 * Represents an menu item. A tap on the item leads to a corresponding
 * search action.
 */
@interface YMKSearchMenuItem : NSObject

/**
 * Menu item title.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *title;

/**
 * Menu item subtitle.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *subtitle;

/**
 * Search query to execute when user clicks on the menu item.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *searchQuery;

/**
 * Types of the menu item (special, advert). Types are empty for normal
 * menu item.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *types;

/**
 * Identifier for logging.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *logId;

/**
 * Menu item icons.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchImage *> *images;

/**
 * Additional menu item properties.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchKeyValuePair *> *properties;


+ (nonnull YMKSearchMenuItem *)menuItemWithTitle:(nullable NSString *)title
                                        subtitle:(nullable NSString *)subtitle
                                     searchQuery:(nullable NSString *)searchQuery
                                           types:(nonnull NSArray<NSString *> *)types
                                           logId:(nullable NSString *)logId
                                          images:(nonnull NSArray<YMKSearchImage *> *)images
                                      properties:(nonnull NSArray<YMKSearchKeyValuePair *> *)properties;


@end
/// @endcond

