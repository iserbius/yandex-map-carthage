#import <YandexMapKitSearch/YMKSearchAvailability.h>
#import <YandexMapKitSearch/YMKSearchWorkingHoursState.h>

/**
 * Open hours for an organization.
 */
@interface YMKSearchWorkingHours : NSObject

/**
 * Human-readable localized open hours description. For example,
 * "пн-пт 10:00-20:00".
 */
@property (nonatomic, readonly, nonnull) NSString *text;

/**
 * Structured open hours information.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchAvailability *> *availabilities;

/**
 * Current company working status
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchWorkingHoursState *state;


+ (nonnull YMKSearchWorkingHours *)workingHoursWithText:(nonnull NSString *)text
                                         availabilities:(nonnull NSArray<YMKSearchAvailability *> *)availabilities
                                                  state:(nullable YMKSearchWorkingHoursState *)state;


@end

