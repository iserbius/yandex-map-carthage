#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Disclaimer text.
 */
@interface YMKSearchDisclaimer : NSObject

/**
 * Disclaimer text.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *text;


+ (nonnull YMKSearchDisclaimer *)disclaimerWithText:(nullable NSString *)text;


@end
/// @endcond

