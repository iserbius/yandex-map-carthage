#import <Foundation/Foundation.h>

/// @cond EXCLUDE
@interface YMKSearchAdvertImage : NSObject

/**
 * Url for the image.
 */
@property (nonatomic, readonly, nonnull) NSString *url;

/**
 * Image tags.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;


+ (nonnull YMKSearchAdvertImage *)advertImageWithUrl:(nonnull NSString *)url
                                                tags:(nonnull NSArray<NSString *> *)tags;


@end
/// @endcond

