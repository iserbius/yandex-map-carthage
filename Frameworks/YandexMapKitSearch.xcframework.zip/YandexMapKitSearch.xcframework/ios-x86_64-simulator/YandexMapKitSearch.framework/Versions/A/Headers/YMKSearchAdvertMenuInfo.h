#import <YandexMapKitSearch/YMKSearchAdvertMenuItem.h>

/// @cond EXCLUDE
/**
 * Multiple menu advertisement entries.
 */
@interface YMKSearchAdvertMenuInfo : NSObject

/**
 * Menu items.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchAdvertMenuItem *> *menuItems;


+ (nonnull YMKSearchAdvertMenuInfo *)advertMenuInfoWithMenuItems:(nonnull NSArray<YMKSearchAdvertMenuItem *> *)menuItems;


@end
/// @endcond

