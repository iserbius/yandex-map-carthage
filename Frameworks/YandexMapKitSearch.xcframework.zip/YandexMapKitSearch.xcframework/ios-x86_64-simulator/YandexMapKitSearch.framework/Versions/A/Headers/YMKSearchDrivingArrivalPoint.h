#import <YandexMapKit/YMKGeometry.h>
#import <YandexMapKit/YMKLocalizedValue.h>
#import <YandexMapKit/YMKPoint.h>
#import <YandexMapKit/YMKTaxiMoney.h>

/// @cond EXCLUDE
/**
 * A place where one can arrive using a car
 */
@interface YMKSearchDrivingArrivalPoint : NSObject

/**
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *id;

/**
 * Point to show a balloon at.
 */
@property (nonatomic, readonly, nonnull) YMKPoint *anchor;

/**
 * Geometry of a carpark or a mined cluster of arrival points.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKGeometry *geometry;

/**
 * Walking time from the arrival point to the target point (organization
 * or toponym).
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKLocalizedValue *walkingTime;

/**
 * Price of the first hour.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKTaxiMoney *price;

/**
 * A name from the geocoder or a manually assigned label like
 * "Departures" in the airport terminal.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *description;

/**
 * Tags are a list of features that the arrival point has. Supported
 * tags: parking/drop_off, free/toll/restricted, on_street yard/building
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;


+ (nonnull YMKSearchDrivingArrivalPoint *)drivingArrivalPointWithId:(nullable NSString *)id
                                                             anchor:(nonnull YMKPoint *)anchor
                                                           geometry:(nullable YMKGeometry *)geometry
                                                        walkingTime:(nullable YMKLocalizedValue *)walkingTime
                                                              price:(nullable YMKTaxiMoney *)price
                                                        description:(nullable NSString *)description
                                                               tags:(nonnull NSArray<NSString *> *)tags;


@end
/// @endcond

