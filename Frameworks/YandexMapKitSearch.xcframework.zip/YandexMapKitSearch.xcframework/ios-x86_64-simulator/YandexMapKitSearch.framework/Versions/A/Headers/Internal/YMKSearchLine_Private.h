#import <YandexMapKitSearch/YMKSearchLine.h>

#import <yandex/maps/mapkit/search/masstransit_1x_object_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>

namespace yandex {
namespace maps {
namespace runtime {
namespace bindings {
namespace ios {
namespace internal {

template <>
struct ToNative<::yandex::maps::mapkit::search::Line, YMKSearchLine, void> {
    static ::yandex::maps::mapkit::search::Line from(
        YMKSearchLine* platformLine);
};

template <typename PlatformType>
struct ToNative<::yandex::maps::mapkit::search::Line, PlatformType,
        typename std::enable_if<
            std::is_convertible<PlatformType, YMKSearchLine*>::value>::type> {
    static ::yandex::maps::mapkit::search::Line from(
        PlatformType platformLine)
    {
        return ToNative<::yandex::maps::mapkit::search::Line, YMKSearchLine>::from(
            platformLine);
    }
};

template <>
struct ToPlatform<::yandex::maps::mapkit::search::Line> {
    static YMKSearchLine* from(
        const ::yandex::maps::mapkit::search::Line& line);
};

} // namespace internal
} // namespace ios
} // namespace bindings
} // namespace runtime
} // namespace maps
} // namespace yandex
