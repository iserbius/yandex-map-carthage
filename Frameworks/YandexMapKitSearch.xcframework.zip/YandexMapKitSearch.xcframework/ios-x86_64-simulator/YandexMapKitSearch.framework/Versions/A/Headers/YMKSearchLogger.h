#import <YandexMapKit/YMKGeoObject.h>

/// @cond EXCLUDE
typedef NS_ENUM(NSUInteger, YMKSearchBannerEvent) {

    YMKSearchBannerEventShow,

    YMKSearchBannerEventClick
};
/// @endcond


/// @cond EXCLUDE
typedef NS_ENUM(NSUInteger, YMKSearchActionButtonEvent) {

    YMKSearchActionButtonEventCall,

    YMKSearchActionButtonEventSearch,

    YMKSearchActionButtonEventOpenSite,

    YMKSearchActionButtonEventOpenApp,

    YMKSearchActionButtonEventSaveOffer
};
/// @endcond


/// @cond EXCLUDE
typedef NS_ENUM(NSUInteger, YMKSearchNavigationButtonEvent) {

    YMKSearchNavigationButtonEventGo,

    YMKSearchNavigationButtonEventVia
};
/// @endcond


/// @cond EXCLUDE
/**
 * Event logger.
 */
@interface YMKSearchLogger : NSObject

/**
 *
 * @param event event type
 * @param geoObject geoObject with billboard metadata
 */
- (void)logActionButtonWithEvent:(YMKSearchActionButtonEvent)event
                       geoObject:(nonnull YMKGeoObject *)geoObject;


- (void)logNavigationButtonWithEvent:(YMKSearchNavigationButtonEvent)event
                           geoObject:(nonnull YMKGeoObject *)geoObject;


- (void)logViaBannerWithEvent:(YMKSearchBannerEvent)event
                    geoObject:(nonnull YMKGeoObject *)geoObject;


- (void)logZeroSpeedBannerWithEvent:(YMKSearchBannerEvent)event
                          geoObject:(nonnull YMKGeoObject *)geoObject;


- (void)obsoleteLogBillboardWithEvent:(YMKSearchBannerEvent)event
                            geoObject:(nonnull YMKGeoObject *)geoObject;


@end
/// @endcond

