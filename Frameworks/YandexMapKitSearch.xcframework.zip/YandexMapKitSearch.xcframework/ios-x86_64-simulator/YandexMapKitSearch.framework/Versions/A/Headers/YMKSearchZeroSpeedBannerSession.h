#import <YandexMapKitSearch/YMKSearchBillboardObjectMetadata.h>

#import <YandexMapKit/YMKGeoObject.h>

/// @cond EXCLUDE
typedef void(^YMKSearchZeroSpeedBannerSessionResponseHandler)(
    YMKGeoObject * _Nullable banner);


/**
 * Session to be notified when a zero speed banner is received or no
 * banner is available.
 */
@interface YMKSearchZeroSpeedBannerSession : NSObject

- (void)cancel;


@end
/// @endcond

