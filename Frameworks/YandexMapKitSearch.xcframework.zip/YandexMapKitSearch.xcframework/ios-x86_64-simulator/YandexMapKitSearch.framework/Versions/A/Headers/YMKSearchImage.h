#import <Foundation/Foundation.h>

@interface YMKSearchImage : NSObject

/**
 * urlTemplate for the image.
 */
@property (nonatomic, readonly, nonnull) NSString *urlTemplate;

/**
 * Image tags.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;


+ (nonnull YMKSearchImage *)imageWithUrlTemplate:(nonnull NSString *)urlTemplate
                                            tags:(nonnull NSArray<NSString *> *)tags;


@end

