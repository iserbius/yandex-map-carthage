#import <YandexMapKitSearch/YMKSearchBillboardObjectMetadata.h>

#import <yandex/maps/mapkit/search/billboard_object_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


