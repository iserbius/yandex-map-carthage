#import <YandexMapKitSearch/YMKSearchMenuInfo.h>
#import <YandexMapKitSearch/YMKSearchMenuListener.h>

#import <YandexMapKit/YMKPoint.h>

/// @cond EXCLUDE
/**
 * An interface for receiving menu items for the application menu. The
 * application sets the user position and the relevant menu are
 * provided. Menu data are received in the background, and the
 * application is notified when new menu become available. Last used
 * menu data are stored to disk, and first notification is sent with
 * stored data.
 */
@interface YMKSearchMenuManager : NSObject

/**
 * Adds a listener to receive menu.
 *
 * @param menuListener Listener to add.
 */
- (void)addListenerWithMenuListener:(nonnull id<YMKSearchMenuListener>)menuListener;


/**
 * Removes the listener for menu.
 *
 * @param menuListener Listener to remove.
 */
- (void)removeListenerWithMenuListener:(nonnull id<YMKSearchMenuListener>)menuListener;


/**
 * Sets the current position.
 *
 * @param point New position value.
 */
- (void)setPositionWithPoint:(nonnull YMKPoint *)point;


/**
 * Currently available menu.
 *
 * @return collection of menu items.
 */
@property (nonatomic, readonly, nonnull) YMKSearchMenuInfo *menuInfo;

@end
/// @endcond

