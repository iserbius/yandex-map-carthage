#import <YandexMapKitSearch/YMKSearchAbsoluteDistance.h>
#import <YandexMapKitSearch/YMKSearchRelativeDistance.h>

/// @cond EXCLUDE
/**
 * Snippet data to get route distance info.
 */
@interface YMKSearchRouteDistancesObjectMetadata : NSObject

/**
 * Absolute distance info.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchAbsoluteDistance *absolute;

/**
 * Relative distance info.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchRelativeDistance *relative;


+ (nonnull YMKSearchRouteDistancesObjectMetadata *)routeDistancesObjectMetadataWithAbsolute:(nullable YMKSearchAbsoluteDistance *)absolute
                                                                                   relative:(nullable YMKSearchRelativeDistance *)relative;


@end
/// @endcond

