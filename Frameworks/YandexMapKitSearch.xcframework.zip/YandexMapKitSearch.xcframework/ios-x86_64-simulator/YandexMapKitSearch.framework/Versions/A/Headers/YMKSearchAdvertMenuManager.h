#import <YandexMapKitSearch/YMKSearchAdvertMenuInfo.h>
#import <YandexMapKitSearch/YMKSearchAdvertMenuListener.h>

#import <YandexMapKit/YMKPoint.h>

/// @cond EXCLUDE
/**
 * An interface for receiving advertised menu items for the application
 * menu. The application sets the user position and the relevant menu
 * advertisements are provided. Ads are received in the background and
 * the application is notified when new menu advertisements become
 * available.
 */
@interface YMKSearchAdvertMenuManager : NSObject

/**
 * Add a listener to receive menu advertisements. The listener will be
 * notified after calls to setPosition.
 *
 * @param menuListener listener to add
 */
- (void)addListenerWithMenuListener:(nonnull id<YMKSearchAdvertMenuListener>)menuListener;


/**
 * Remove the menu advertisement listener.
 *
 * @param menuListener listener to remove
 */
- (void)removeListenerWithMenuListener:(nonnull id<YMKSearchAdvertMenuListener>)menuListener;


/**
 * Set the current position.
 *
 * @param point new position value
 */
- (void)setPositionWithPoint:(nonnull YMKPoint *)point;


/**
 * Currently available menu advertisements.
 *
 * @return collection of menu advertisment items.
 */
@property (nonatomic, readonly, nonnull) YMKSearchAdvertMenuInfo *advertMenuInfo;

@end
/// @endcond

