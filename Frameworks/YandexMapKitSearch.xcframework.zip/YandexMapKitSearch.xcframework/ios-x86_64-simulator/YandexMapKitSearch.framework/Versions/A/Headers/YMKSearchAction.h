#import <YandexMapKitSearch/YMKSearchKeyValuePair.h>

/// @cond EXCLUDE
/**
 * CTA https://en.wikipedia.org/wiki/Call_to_action_(marketing)
 */
@interface YMKSearchAction : NSObject

/**
 * Action type.
 */
@property (nonatomic, readonly, nonnull) NSString *type;

/**
 * Additional action properties.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchKeyValuePair *> *properties;


+ (nonnull YMKSearchAction *)actionWithType:(nonnull NSString *)type
                                 properties:(nonnull NSArray<YMKSearchKeyValuePair *> *)properties;


@end
/// @endcond

