#import <YandexMapKitSearch/YMKSearchBusinessRating2xObjectMetadata.h>

#import <yandex/maps/mapkit/search/business_rating_2x_object_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


