#import <YandexMapKitSearch/YMKSearchStop.h>

/// @cond EXCLUDE
/**
 * Snippet data to get mass transit stop info.
 */
@interface YMKSearchMassTransit1xObjectMetadata : NSObject

/**
 * List of neareast mass transit stops.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchStop *> *stops;


+ (nonnull YMKSearchMassTransit1xObjectMetadata *)massTransit1xObjectMetadataWithStops:(nonnull NSArray<YMKSearchStop *> *)stops;


@end
/// @endcond

