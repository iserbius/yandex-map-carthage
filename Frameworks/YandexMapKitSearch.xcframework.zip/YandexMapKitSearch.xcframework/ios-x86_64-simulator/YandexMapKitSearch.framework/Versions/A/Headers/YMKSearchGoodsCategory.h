#import <YandexMapKitSearch/YMKSearchGoods.h>

/// @cond EXCLUDE
/**
 * Named category of goods.
 */
@interface YMKSearchGoodsCategory : NSObject

/**
 * Category name.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *name;

/**
 * Several goods objects in a category.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchGoods *> *goods;


+ (nonnull YMKSearchGoodsCategory *)goodsCategoryWithName:(nullable NSString *)name
                                                    goods:(nonnull NSArray<YMKSearchGoods *> *)goods;


@end
/// @endcond

