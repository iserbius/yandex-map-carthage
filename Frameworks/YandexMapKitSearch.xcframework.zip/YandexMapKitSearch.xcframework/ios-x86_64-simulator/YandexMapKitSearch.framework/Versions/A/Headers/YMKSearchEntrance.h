#import <YandexMapKit/YMKDirection.h>
#import <YandexMapKit/YMKPoint.h>

/**
 * An entrance to a building
 */
@interface YMKSearchEntrance : NSObject

/**
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *name;

@property (nonatomic, readonly, nonnull) YMKPoint *point;

/**
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKDirection *direction;


+ (nonnull YMKSearchEntrance *)entranceWithName:(nullable NSString *)name
                                          point:(nonnull YMKPoint *)point
                                      direction:(nullable YMKDirection *)direction;


@end

