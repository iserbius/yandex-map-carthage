#import <Foundation/Foundation.h>

@class YMKSearchResultItem;

/**
 * Interface for callbacks on placemark events.
 */
@protocol YMKSearchLayerTapHandler <NSObject>

/**
 * Called when user taps on placemark.
 *
 * @param searchResultItem Corresponding search result.
 */
- (BOOL)onTapWithSearchResultItem:(nonnull YMKSearchResultItem *)searchResultItem;


@end
