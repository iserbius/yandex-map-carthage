#import <YandexMapKitSearch/YMKSearchLayerResponseHandler.h>

#import <yandex/maps/mapkit/search/search_layer/search_layer.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>

namespace yandex {
namespace maps {
namespace mapkit {
namespace search {
namespace search_layer {
namespace ios {

class SearchResultListenerBinding : public ::yandex::maps::mapkit::search::search_layer::SearchResultListener {
public:
    explicit SearchResultListenerBinding(
        id<YMKSearchLayerResponseHandler> platformListener);

    virtual void onSearchStart() override;

    virtual void onSearchSuccess() override;

    virtual void onSearchError(
        ::yandex::maps::runtime::Error* error) override;

    virtual void onPresentedResultsUpdate() override;

    virtual void onAllResultsClear() override;

    id<YMKSearchLayerResponseHandler> platformReference() const { return platformListener_; }

private:
    __weak id<YMKSearchLayerResponseHandler> platformListener_;
};

} // namespace ios
} // namespace search_layer
} // namespace search
} // namespace mapkit
} // namespace maps
} // namespace yandex

namespace yandex {
namespace maps {
namespace runtime {
namespace bindings {
namespace ios {
namespace internal {

template <>
struct ToNative<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::SearchResultListener>, id<YMKSearchLayerResponseHandler>, void> {
    static std::shared_ptr<::yandex::maps::mapkit::search::search_layer::SearchResultListener> from(
        id<YMKSearchLayerResponseHandler> platformSearchResultListener);
};
template <typename PlatformType>
struct ToNative<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::SearchResultListener>, PlatformType> {
    static std::shared_ptr<::yandex::maps::mapkit::search::search_layer::SearchResultListener> from(
        PlatformType platformSearchResultListener)
    {
        return ToNative<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::SearchResultListener>, id<YMKSearchLayerResponseHandler>>::from(
            platformSearchResultListener);
    }
};

template <>
struct ToPlatform<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::SearchResultListener>> {
    static id<YMKSearchLayerResponseHandler> from(
        const std::shared_ptr<::yandex::maps::mapkit::search::search_layer::SearchResultListener>& nativeSearchResultListener);
};

} // namespace internal
} // namespace ios
} // namespace bindings
} // namespace runtime
} // namespace maps
} // namespace yandex
