#import <YandexMapKitSearch/YMKSearchCategory.h>

#import <yandex/maps/mapkit/search/category.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


