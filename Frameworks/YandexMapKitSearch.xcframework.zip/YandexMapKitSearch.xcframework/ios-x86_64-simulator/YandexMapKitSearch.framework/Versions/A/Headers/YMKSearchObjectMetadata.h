#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * General snippet.
 */
@interface YMKSearchObjectMetadata : NSObject

/**
 * Server-generated log identifier.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *logId;

/**
 * Server-generated request identifier.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *reqId;


+ (nonnull YMKSearchObjectMetadata *)searchObjectMetadataWithLogId:(nullable NSString *)logId
                                                             reqId:(nullable NSString *)reqId;


@end
/// @endcond

