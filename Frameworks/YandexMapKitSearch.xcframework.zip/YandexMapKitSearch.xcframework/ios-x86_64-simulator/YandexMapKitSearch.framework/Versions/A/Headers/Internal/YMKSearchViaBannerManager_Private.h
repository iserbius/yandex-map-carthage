#import <YandexMapKitSearch/YMKSearchViaBannerManager.h>

#import <yandex/maps/mapkit/search/via_banner_manager.h>

#import <memory>

@interface YMKSearchViaBannerManager ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(const std::shared_ptr<::yandex::maps::mapkit::search::ViaBannerManager>&)native;

- (std::shared_ptr<::yandex::maps::mapkit::search::ViaBannerManager>)nativeViaBannerManager;
- (std::shared_ptr<::yandex::maps::mapkit::search::ViaBannerManager>)native;

@end
