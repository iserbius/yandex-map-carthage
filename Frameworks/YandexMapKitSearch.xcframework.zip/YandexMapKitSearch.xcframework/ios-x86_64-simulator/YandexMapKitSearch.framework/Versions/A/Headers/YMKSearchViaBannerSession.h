#import <YandexMapKit/YMKGeoObject.h>

/// @cond EXCLUDE
typedef void(^YMKSearchViaBannerSessionResponseHandler)(
    YMKGeoObject * _Nullable banner);


/**
 * Session for requesting via banner for route.
 */
@interface YMKSearchViaBannerSession : NSObject

- (void)cancel;


@end
/// @endcond

