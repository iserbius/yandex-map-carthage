#import <Foundation/Foundation.h>

@interface YMKSearchUtils : NSObject

+ (nonnull NSString *)makeBusinessUriWithOid:(nonnull NSString *)oid;


@end
