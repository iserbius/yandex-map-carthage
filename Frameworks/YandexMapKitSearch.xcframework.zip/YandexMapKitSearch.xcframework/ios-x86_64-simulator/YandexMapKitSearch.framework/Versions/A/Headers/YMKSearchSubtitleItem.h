#import <YandexMapKitSearch/YMKSearchKeyValuePair.h>

/**
 * Separate subtitle of a certain type.
 */
@interface YMKSearchSubtitleItem : NSObject

/**
 * Subtitle type. For example, "exchange".
 */
@property (nonatomic, readonly, nonnull) NSString *type;

/**
 * Short summary text. For example, "USD 57.69/57.3".
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *text;

/**
 * Detailed subtitle info. For example, [ {"key": "currency", "value":
 * "USD"}, {"key": "buy", "value": "57.3"}, {"key": "sell", "value":
 * "57.69"} ].
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchKeyValuePair *> *properties;


+ (nonnull YMKSearchSubtitleItem *)subtitleItemWithType:(nonnull NSString *)type
                                                   text:(nullable NSString *)text
                                             properties:(nonnull NSArray<YMKSearchKeyValuePair *> *)properties;


@end

