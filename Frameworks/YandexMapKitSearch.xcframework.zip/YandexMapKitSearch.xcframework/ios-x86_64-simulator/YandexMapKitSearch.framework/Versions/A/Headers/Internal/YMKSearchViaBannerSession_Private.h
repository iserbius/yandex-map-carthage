#import <YandexMapKitSearch/YMKSearchViaBannerSession.h>

#import <yandex/maps/mapkit/search/via_banner_manager.h>

#import <memory>

namespace yandex {
namespace maps {
namespace mapkit {
namespace search {
namespace ios {

ViaBannerSession::OnViaBanner onViaBanner(
    YMKSearchViaBannerSessionResponseHandler handler);

} // namespace ios
} // namespace search
} // namespace mapkit
} // namespace maps
} // namespace yandex

@interface YMKSearchViaBannerSession ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(std::unique_ptr<::yandex::maps::mapkit::search::ViaBannerSession>)native;

- (::yandex::maps::mapkit::search::ViaBannerSession *)nativeViaBannerSession;

@end
