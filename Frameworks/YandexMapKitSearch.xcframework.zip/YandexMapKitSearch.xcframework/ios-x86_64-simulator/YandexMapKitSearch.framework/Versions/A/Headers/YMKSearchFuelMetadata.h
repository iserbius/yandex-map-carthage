#import <YandexMapKitSearch/YMKSearchFuelType.h>

#import <YandexMapKit/YMKAttribution.h>

/**
 * Fuel snippet.
 */
@interface YMKSearchFuelMetadata : NSObject

/**
 * Snippet update time as UNIX timestamp.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSNumber *timestamp;

/**
 * Fuel list.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchFuelType *> *fuels;

/**
 * Attribution information.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKAttribution *attribution;


+ (nonnull YMKSearchFuelMetadata *)fuelMetadataWithTimestamp:(nullable NSNumber *)timestamp
                                                       fuels:(nonnull NSArray<YMKSearchFuelType *> *)fuels
                                                 attribution:(nullable YMKAttribution *)attribution;


@end

