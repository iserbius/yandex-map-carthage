#import <YandexMapKitSearch/YMKSearchShowtime.h>

/**
 * Event schedule snippet.
 */
@interface YMKSearchShowtimesObjectMetadata : NSObject

/**
 * Event title.
 */
@property (nonatomic, readonly, nonnull) NSString *title;

/**
 * List of showtimes.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchShowtime *> *showtimes;


+ (nonnull YMKSearchShowtimesObjectMetadata *)showtimesObjectMetadataWithTitle:(nonnull NSString *)title
                                                                     showtimes:(nonnull NSArray<YMKSearchShowtime *> *)showtimes;


@end

