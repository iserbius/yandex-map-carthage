#import <YandexMapKitSearch/YMKSearch.h>

@interface YMKSearch (Factory)

+ (instancetype)search;
+ (instancetype)sharedInstance;

@end
