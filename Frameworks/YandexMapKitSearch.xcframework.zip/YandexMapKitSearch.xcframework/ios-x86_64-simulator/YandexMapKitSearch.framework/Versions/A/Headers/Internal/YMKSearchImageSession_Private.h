#import <YandexMapKitSearch/YMKSearchImageSession.h>

#import <yandex/maps/mapkit/search/image_downloader.h>

#import <memory>

@interface YMKSearchImageSession ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(std::unique_ptr<::yandex::maps::mapkit::search::ImageSession>)native;

- (::yandex::maps::mapkit::search::ImageSession *)nativeImageSession;

@end
