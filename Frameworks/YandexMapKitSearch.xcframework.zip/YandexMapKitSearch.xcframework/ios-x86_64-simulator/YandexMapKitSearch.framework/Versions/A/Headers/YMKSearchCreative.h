#import <YandexMapKitSearch/YMKSearchKeyValuePair.h>

/// @cond EXCLUDE
/**
 * Visible piece of advertising art.
 */
@interface YMKSearchCreative : NSObject

/**
 * Creative ID.
 */
@property (nonatomic, readonly, nonnull) NSString *id;

/**
 * Creative type.
 */
@property (nonatomic, readonly, nonnull) NSString *type;

/**
 * Additional creative properties.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchKeyValuePair *> *properties;


+ (nonnull YMKSearchCreative *)creativeWithId:(nonnull NSString *)id
                                         type:(nonnull NSString *)type
                                   properties:(nonnull NSArray<YMKSearchKeyValuePair *> *)properties;


@end
/// @endcond

