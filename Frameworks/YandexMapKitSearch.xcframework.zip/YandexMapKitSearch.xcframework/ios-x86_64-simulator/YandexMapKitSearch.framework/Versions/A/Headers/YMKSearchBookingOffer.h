#import <YandexMapKitSearch/YMKSearchBookingLink.h>
#import <YandexMapKitSearch/YMKSearchImage.h>

#import <YandexMapKit/YMKTaxiMoney.h>

/// @cond EXCLUDE
/**
 * Information about offer partner and price.
 */
@interface YMKSearchBookingOffer : NSObject

/**
 * Partner name. For example 'Яндекс.Путешествия'.
 */
@property (nonatomic, readonly, nonnull) NSString *partnerName;

/**
 * Typed links for actual booking.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchBookingLink *> *bookingLinks;

/**
 * Parnter favicon.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchImage *favicon;

/**
 * Booking price.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKTaxiMoney *price;


+ (nonnull YMKSearchBookingOffer *)bookingOfferWithPartnerName:(nonnull NSString *)partnerName
                                                  bookingLinks:(nonnull NSArray<YMKSearchBookingLink *> *)bookingLinks
                                                       favicon:(nullable YMKSearchImage *)favicon
                                                         price:(nullable YMKTaxiMoney *)price;


@end
/// @endcond

