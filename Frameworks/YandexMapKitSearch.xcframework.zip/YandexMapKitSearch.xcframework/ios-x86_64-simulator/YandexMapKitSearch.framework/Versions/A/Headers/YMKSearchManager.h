#import <YandexMapKitSearch/YMKSearchBookingRequestParams.h>
#import <YandexMapKitSearch/YMKSearchBookingSearchSession.h>
#import <YandexMapKitSearch/YMKSearchGoodsRegisterSession.h>
#import <YandexMapKitSearch/YMKSearchOptions.h>
#import <YandexMapKitSearch/YMKSearchSession.h>

#import <YandexMapKit/YMKGeometry.h>
#import <YandexMapKit/YMKPoint.h>
#import <YandexMapKit/YMKPolyline.h>

@class YMKSearchSuggestSession;

/**
 * Main interface to start search.
 */
@interface YMKSearchManager : NSObject

/**
 * Search request for searching a user query near given geometry.
 *
 * @param text User query.
 * @param geometry Geometry to search near. Supported types: point,
 * bounding box, polyline and polygon. If the polyline is provided,
 * setSortByDistance(polyline) is assumed on the first request. Polygon
 * is expected to be a search window: 4 points in outer ring (or 5 if
 * the last point is equal to the first) and no inner rings.
 * @param searchOptions Various additional search parameters, see
 * YMKSearchOptions definition for details.
 * @param searchListener Listener to handle search result.
 *
 * @return YMKSearchSession which allows further searches, cancel and
 * retry.
 */
- (nonnull YMKSearchSession *)submitWithText:(nonnull NSString *)text
                                    geometry:(nonnull YMKGeometry *)geometry
                               searchOptions:(nonnull YMKSearchOptions *)searchOptions
                             responseHandler:(nonnull YMKSearchSessionResponseHandler)responseHandler;


/**
 * Search request that is used to search for a user query along the
 * given polyline inside the given window.
 *
 * @param text User query.
 * @param polyline Polyline to search near;
 * YMKSearchSession::setSortByDistanceWithOrigin: is assumed on the
 * first request.
 * @param geometry Geometry to search near; supported types: point,
 * bounding box, polyline and polygon. Polygon is expected to be a
 * search window: 4 points in outer ring (or 5 if the last point is
 * equal to first) and no inner rings.
 * @param searchOptions Various additional search parameters, see
 * YMKSearchOptions definition for details.
 * @param searchListener Listener to handle search result.
 *
 * @return YMKSearchSession which allows further searches, cancel and
 * retry. Session should be stored by user or search is automatically
 * cancelled.
 */
- (nonnull YMKSearchSession *)submitWithText:(nonnull NSString *)text
                                    polyline:(nonnull YMKPolyline *)polyline
                                    geometry:(nonnull YMKGeometry *)geometry
                               searchOptions:(nonnull YMKSearchOptions *)searchOptions
                             responseHandler:(nonnull YMKSearchSessionResponseHandler)responseHandler;


/**
 * Reverse search request (to search objects at the given coordinates)
 *
 * @param point Coordinates to search at.
 * @param zoom Current zoom level. Skips objects that are too small for
 * a given zoom level.
 * @param searchOptions Additional search parameters, see
 * YMKSearchOptions definition for details. Currently the only supported
 * options are YMKSearchOptions::origin, YMKSearchOptions::searchTypes
 * and YMKSearchOptions::snippets. Only 'geo' and 'biz' types are
 * supported and not at the same time.
 * @param searchListener Listener to handle search result.
 *
 * @return YMKSearchSession which allows further searches, cancel and
 * retry. Session should be stored by user or search is automatically
 * cancelled.
 *
 * Remark:
 * @param zoom has optional type, it may be uninitialized.
 */
- (nonnull YMKSearchSession *)submitWithPoint:(nonnull YMKPoint *)point
                                         zoom:(nullable NSNumber *)zoom
                                searchOptions:(nonnull YMKSearchOptions *)searchOptions
                              responseHandler:(nonnull YMKSearchSessionResponseHandler)responseHandler;


/**
 * Search request for URI resolution.
 *
 * @param uri Object uri.
 * @param searchOptions Additional search parameters, see
 * YMKSearchOptions definition for details. Currently the only supported
 * options are YMKSearchOptions::origin and YMKSearchOptions::snippets.
 * @param searchListener Listener to handle search result.
 *
 * @return YMKSearchSession which allows search cancel and retry. Should
 * be stored by user or search is automatically cancelled.
 */
- (nonnull YMKSearchSession *)resolveURIWithUri:(nonnull NSString *)uri
                                  searchOptions:(nonnull YMKSearchOptions *)searchOptions
                                responseHandler:(nonnull YMKSearchSessionResponseHandler)responseHandler;


/**
 * Search request with URI. Allows multiple results in response.
 *
 * @param uri Object uri.
 * @param searchOptions Additional search parameters, see
 * YMKSearchOptions definition for details. Currently the only supported
 * options are YMKSearchOptions::origin, YMKSearchOptions::snippets and.
 * YMKSearchOptions::resultPageSize.
 * @param searchListener Listener to handle search result.
 *
 * @return YMKSearchSession which allows search cancel and retry. Should
 * be stored by user or search is automatically cancelled.
 */
- (nonnull YMKSearchSession *)searchByURIWithUri:(nonnull NSString *)uri
                                   searchOptions:(nonnull YMKSearchOptions *)searchOptions
                                 responseHandler:(nonnull YMKSearchSessionResponseHandler)responseHandler;


/**
 * Search request for goods register.
 *
 * @param uri Uri of object for which goods register is requested.
 * @param goodsRegisterListener Listener to handle search result.
 *
 * @return YMKSearchGoodsRegisterSession which allows search cancel and
 * retry. Should be stored by user or search is automatically cancelled.
 */
- (nonnull YMKSearchGoodsRegisterSession *)requestGoodsRegisterWithUri:(nonnull NSString *)uri
                                                  goodsRegisterHandler:(nonnull YMKSearchGoodsRegisterSessionGoodsRegisterHandler)goodsRegisterHandler;


/// @cond EXCLUDE
/**
 * Request for booking offers.
 *
 * @param uri Uri of object for which booking offers are requested.
 * @param params Additional booking parameters. If not given some
 * default booking offers would be returned alongside with parameters
 * for these default offers.
 * @param bookingSearchListener Listener to handle search result.
 *
 * @return YMKSearchBookingSearchSession which allows search cancel and
 * retry. Should be stored by user or request is automatically
 * cancelled.
 *
 * Remark:
 * @param params has optional type, it may be uninitialized.
 */
- (nonnull YMKSearchBookingSearchSession *)findBookingOffersWithUri:(nonnull NSString *)uri
                                                             params:(nullable YMKSearchBookingRequestParams *)params
                                               bookingSearchHandler:(nonnull YMKSearchBookingSearchSessionBookingSearchHandler)bookingSearchHandler;
/// @endcond


/**
 * Creates session for suggest requests.
 */
- (nonnull YMKSearchSuggestSession *)createSuggestSession;


@end

