#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Contains information about the advertisement.
 */
@interface YMKSearchObsoleteAdvert : NSObject

/**
 * Optional style that can be used to create an icon for the
 * advertisement.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *style;

/**
 * Additional string-based info.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;


+ (nonnull YMKSearchObsoleteAdvert *)obsoleteAdvertWithStyle:(nullable NSString *)style
                                                        tags:(nonnull NSArray<NSString *> *)tags;


@end
/// @endcond

