#import <Foundation/Foundation.h>

/**
 * Base class interface of a location-view source.
 */
@interface YMKLocationViewSource : NSObject

@end

