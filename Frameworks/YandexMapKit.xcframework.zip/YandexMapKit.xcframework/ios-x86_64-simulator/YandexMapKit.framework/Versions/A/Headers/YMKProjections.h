#import <YandexMapKit/YMKProjection.h>

#import <YandexRuntime/YRTExtern.h>

YRT_EXTERN id<YMKProjection> YMKCreateWgs84Mercator();

YRT_EXTERN id<YMKProjection> YMKCreateSphericalMercator();
