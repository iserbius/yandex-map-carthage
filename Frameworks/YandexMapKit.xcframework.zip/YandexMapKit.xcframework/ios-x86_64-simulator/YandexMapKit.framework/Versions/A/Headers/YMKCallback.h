#import <Foundation/Foundation.h>

typedef void(^YMKCallback)(
    );

