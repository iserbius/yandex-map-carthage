#import <YandexMapKit/YMKTrafficRoadEventTapInfo.h>

#import <yandex/maps/mapkit/traffic/road_event_tap_info.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


