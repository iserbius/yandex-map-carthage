#import <YandexMapKit/YMKGeoObjectSelectionMetadata.h>

#import <yandex/maps/mapkit/map/geo_object_selection_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


