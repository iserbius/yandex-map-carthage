#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Gets the updated list of experiments.
 */
@protocol YMKUiExperimentsListener <NSObject>

- (void)onParametersUpdated;


@end
/// @endcond
