#import <Foundation/Foundation.h>

@class YMKPanoramaPlayer;

/**
 * Listener to handle possible errors.
 */
@protocol YMKPanoramaErrorDelegate <NSObject>

/**
 * Error notification listener for the panoramaOpen class. Called if the
 * panorama could not be opened.
 */
- (void)onPanoramaOpenErrorWithPlayer:(nonnull YMKPanoramaPlayer *)player
                                error:(nonnull NSError *)error;


@end
