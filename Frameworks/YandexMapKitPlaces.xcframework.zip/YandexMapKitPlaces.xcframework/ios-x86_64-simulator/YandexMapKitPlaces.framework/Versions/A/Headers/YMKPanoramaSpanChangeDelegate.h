#import <Foundation/Foundation.h>

@class YMKPanoramaPlayer;

/**
 * Listener to handle the change in panorama span.
 */
@protocol YMKPanoramaSpanChangeDelegate <NSObject>

/**
 * Called if the user changed the zoom level or the span has been
 * changed by the setSpan method.
 *
 * @param player Panorama player that sent the event.
 */
- (void)onPanoramaSpanChangedWithPlayer:(nonnull YMKPanoramaPlayer *)player;


@end
