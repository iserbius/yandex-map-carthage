#import <YandexMapKitPlaces/YMKPhotosManager.h>

#import <yandex/maps/mapkit/places/photos/photos_manager.h>

#import <memory>

@interface YMKPhotosManager ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(std::unique_ptr<::yandex::maps::mapkit::places::photos::PhotosManager>)native;

- (::yandex::maps::mapkit::places::photos::PhotosManager *)nativePhotosManager;

@end
