#import <UIKit/UIKit.h>

/// @cond EXCLUDE
typedef void(^YMKPhotosImageSessionHandler)(
    UIImage * _Nullable bitmap,
    NSError * _Nullable error);


/**
 * Provides images.
 */
@interface YMKPhotosImageSession : NSObject

/**
 * Cancels the pending image request, if there is one.
 */
- (void)cancel;


/**
 * Re-fetches the image with the same parameters, but a different
 * listener.
 */
- (void)retryWithHandler:(nonnull YMKPhotosImageSessionHandler)handler;


@end
/// @endcond

