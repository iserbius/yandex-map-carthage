#import <Foundation/Foundation.h>

@class YMKPanoramaPlayer;

/**
 * Listener to handle the panorama being opened or changed.
 */
@protocol YMKPanoramaChangeDelegate <NSObject>

/**
 * Called if the panorama was opened or changed by the user. You can get
 * the panoramaId by using the panoramaId() method.
 *
 * @param player Panorama player that sent the event.
 */
- (void)onPanoramaChangedWithPlayer:(nonnull YMKPanoramaPlayer *)player;


@end
