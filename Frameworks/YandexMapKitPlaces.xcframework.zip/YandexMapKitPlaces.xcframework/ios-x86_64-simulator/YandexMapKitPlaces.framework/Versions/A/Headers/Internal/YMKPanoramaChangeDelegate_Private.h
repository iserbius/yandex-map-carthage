#import <YandexMapKitPlaces/YMKPanoramaChangeDelegate.h>

#import <yandex/maps/mapkit/places/panorama/player.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>

namespace yandex {
namespace maps {
namespace mapkit {
namespace places {
namespace panorama {
namespace ios {

class PanoramaChangeListenerBinding : public ::yandex::maps::mapkit::places::panorama::PanoramaChangeListener {
public:
    explicit PanoramaChangeListenerBinding(
        id<YMKPanoramaChangeDelegate> platformListener);

    virtual void onPanoramaChanged(
        ::yandex::maps::mapkit::places::panorama::Player* player) override;

    id<YMKPanoramaChangeDelegate> platformReference() const { return platformListener_; }

private:
    __weak id<YMKPanoramaChangeDelegate> platformListener_;
};

} // namespace ios
} // namespace panorama
} // namespace places
} // namespace mapkit
} // namespace maps
} // namespace yandex

namespace yandex {
namespace maps {
namespace runtime {
namespace bindings {
namespace ios {
namespace internal {

template <>
struct ToNative<std::shared_ptr<::yandex::maps::mapkit::places::panorama::PanoramaChangeListener>, id<YMKPanoramaChangeDelegate>, void> {
    static std::shared_ptr<::yandex::maps::mapkit::places::panorama::PanoramaChangeListener> from(
        id<YMKPanoramaChangeDelegate> platformPanoramaChangeListener);
};
template <typename PlatformType>
struct ToNative<std::shared_ptr<::yandex::maps::mapkit::places::panorama::PanoramaChangeListener>, PlatformType> {
    static std::shared_ptr<::yandex::maps::mapkit::places::panorama::PanoramaChangeListener> from(
        PlatformType platformPanoramaChangeListener)
    {
        return ToNative<std::shared_ptr<::yandex::maps::mapkit::places::panorama::PanoramaChangeListener>, id<YMKPanoramaChangeDelegate>>::from(
            platformPanoramaChangeListener);
    }
};

template <>
struct ToPlatform<std::shared_ptr<::yandex::maps::mapkit::places::panorama::PanoramaChangeListener>> {
    static id<YMKPanoramaChangeDelegate> from(
        const std::shared_ptr<::yandex::maps::mapkit::places::panorama::PanoramaChangeListener>& nativePanoramaChangeListener);
};

} // namespace internal
} // namespace ios
} // namespace bindings
} // namespace runtime
} // namespace maps
} // namespace yandex
