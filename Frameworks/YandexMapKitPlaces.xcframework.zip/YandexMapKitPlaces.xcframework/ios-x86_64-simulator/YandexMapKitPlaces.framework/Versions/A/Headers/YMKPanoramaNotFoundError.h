#import <YandexRuntime/YRTError.h>

/**
 * The panorama was not found.
 */
@interface YMKPanoramaNotFoundError : YRTError

@end

