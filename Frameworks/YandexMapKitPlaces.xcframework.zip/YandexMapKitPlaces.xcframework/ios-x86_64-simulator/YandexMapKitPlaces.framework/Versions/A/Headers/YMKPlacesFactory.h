#import <YandexMapKitPlaces/YMKPlaces.h>

@interface YMKPlaces (Factory)

+ (instancetype)places;
+ (instancetype)sharedInstance;

@end
