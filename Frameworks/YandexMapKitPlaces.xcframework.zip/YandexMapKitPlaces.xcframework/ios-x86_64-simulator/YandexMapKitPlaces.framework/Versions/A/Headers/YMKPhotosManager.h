#import <YandexMapKitPlaces/YMKPhotosImageSession.h>

@class YMKPhotosSession;

/// @cond EXCLUDE
/**
 * Presents photos requesting an API.
 */
@interface YMKPhotosManager : NSObject

/**
 * Returns PhotoSession, which represents a photo feed of the given
 * business.
 */
- (nonnull YMKPhotosSession *)photosWithBusinessId:(nonnull NSString *)businessId;


/**
 * Returns PhotoSession, which represents a photo feed of the given
 * business. The feed only contains photos with the given tags.
 */
- (nonnull YMKPhotosSession *)photosWithBusinessId:(nonnull NSString *)businessId
                                              tags:(nonnull NSArray<NSString *> *)tags;


/**
 * Requests the image with a particular ID and size.
 */
- (nonnull YMKPhotosImageSession *)imageWithId:(nonnull NSString *)id
                                          size:(nonnull NSString *)size
                                       handler:(nonnull YMKPhotosImageSessionHandler)handler;


/**
 * Removes all cached images.
 */
- (void)clear;


@end
/// @endcond

