#import <YandexRuntime/YRTRemoteError.h>

/**
 * Request entity is too large.
 */
@interface YRTRequestEntityTooLargeError : YRTRemoteError

@end

