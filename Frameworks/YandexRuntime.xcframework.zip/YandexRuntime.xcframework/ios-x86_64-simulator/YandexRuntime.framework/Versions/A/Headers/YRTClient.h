#import <Foundation/Foundation.h>

/// @cond EXCLUDE
@interface YRTClient : NSObject

- (void)handleWithData:(nonnull NSData *)data;


@end
/// @endcond

