#import <YandexRuntime/YRTRuntime.h>

#import <yandex/maps/runtime/runtime.h>

#import <memory>

namespace yandex {
namespace maps {
namespace runtime {
namespace ios {

OnFailedAssertion onFailedAssertion(
    YRTFailedAssertionListener handler);

} // namespace ios
} // namespace runtime
} // namespace maps
} // namespace yandex


