#pragma once

#import <Foundation/Foundation.h>

@interface YRTNativeObject : NSObject

@end


