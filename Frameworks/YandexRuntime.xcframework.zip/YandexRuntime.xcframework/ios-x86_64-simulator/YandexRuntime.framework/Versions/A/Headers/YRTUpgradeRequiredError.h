#import <YandexRuntime/YRTError.h>

/// @cond EXCLUDE
@interface YRTUpgradeRequiredError : YRTError

@end
/// @endcond

