#import <YandexRuntime/YRTError.h>

/**
 * Failed to retrieve data due to network instability.
 */
@interface YRTNetworkError : YRTError

@end

