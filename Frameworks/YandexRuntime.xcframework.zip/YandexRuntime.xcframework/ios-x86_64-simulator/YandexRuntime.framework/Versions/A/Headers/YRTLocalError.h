#import <YandexRuntime/YRTError.h>

/**
 * Local error has occurred.
 */
@interface YRTLocalError : YRTError

@end

