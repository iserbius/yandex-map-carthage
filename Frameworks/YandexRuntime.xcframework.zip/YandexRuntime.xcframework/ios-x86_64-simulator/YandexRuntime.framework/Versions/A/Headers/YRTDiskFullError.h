#import <YandexRuntime/YRTLocalError.h>

/**
 * Disk is full.
 */
@interface YRTDiskFullError : YRTLocalError

@end

