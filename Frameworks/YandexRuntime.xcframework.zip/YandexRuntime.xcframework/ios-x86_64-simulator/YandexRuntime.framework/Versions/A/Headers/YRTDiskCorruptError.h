#import <YandexRuntime/YRTLocalError.h>

/**
 * Disk is corrupted.
 */
@interface YRTDiskCorruptError : YRTLocalError

@end

