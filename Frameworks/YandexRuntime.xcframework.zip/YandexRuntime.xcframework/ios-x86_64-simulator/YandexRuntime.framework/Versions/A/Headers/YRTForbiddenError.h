#import <YandexRuntime/YRTRemoteError.h>

/**
 * You are not allowed to access the requested object.
 */
@interface YRTForbiddenError : YRTRemoteError

@end

